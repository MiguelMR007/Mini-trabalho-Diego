#include <stdio.h>
#include <stdlib.h>
#include <time.h>

void bubbleSort(int vetor[], int tamanho) {
    int i, j, auxiliar;

    for (i = 0; i < tamanho - 1; i++) {
        for (j = 0; j < tamanho - 1 - i; j++) {
            if (vetor[j] > vetor[j + 1]) {
                auxiliar = vetor[j];
                vetor[j] = vetor[j + 1];
                vetor[j + 1] = auxiliar;
            }
        }
    }
}

void selectionSort(int vetor[], int tamanho) {
    int i, j, min, auxiliar;

    for (i = 0; i < tamanho - 1; i++) {
        min = i;
        for (j = i + 1; j < tamanho; j++) {
            if (vetor[j] < vetor[min]) {
                min = j;
            }
        }
        if (min != i) {
            auxiliar = vetor[i];
            vetor[i] = vetor[min];
            vetor[min] = auxiliar;
        }
    }
}

int main() {
    FILE *arquivo;
    int vetorOriginal[20000];
    int vetorTrabalho[20000];
    // -----
    int tamanho = 20000;
    int i;
    clock_t inicio, fim;
    double tempoBubble, tempoSelection;
    // ------
    arquivo = fopen("dados-20000-aleatoria.txt", "r");
    if (arquivo == NULL) {
        printf("Erro ao abrir o arquivo.\n");
        return 1;
    }

    for (i = 0; i < tamanho; i++) {
        if (fscanf(arquivo, "%d", &vetorOriginal[i]) != 1) {
            printf("Erro ao ler os dados.\n");
            fclose(arquivo);
            return 1;
        }
    }

    fclose(arquivo);

    for (i = 0; i < tamanho; i++) {
        vetorTrabalho[i] = vetorOriginal[i];
    }

    inicio = clock();
    bubbleSort(vetorTrabalho, tamanho);
    fim = clock();
    tempoBubble = (double)(fim - inicio) / CLOCKS_PER_SEC;

    for (i = 0; i < tamanho; i++) {
        vetorTrabalho[i] = vetorOriginal[i];
    }

    inicio = clock();
    selectionSort(vetorTrabalho, tamanho);
    fim = clock();
    tempoSelection = (double)(fim - inicio) / CLOCKS_PER_SEC;

    printf("Tempo do Bubble Sort    : %.6f segundos\n", tempoBubble);
    printf("Tempo do Selection Sort : %.6f segundos\n\n", tempoSelection);

    printf("Vetor ordenado (primeiros 100 elementos):\n");
    for (i = 0; i < 100 && i < tamanho; i++) {
        printf("%d ", vetorTrabalho[i]);
    }
    printf("\n");

    return 0;
}
