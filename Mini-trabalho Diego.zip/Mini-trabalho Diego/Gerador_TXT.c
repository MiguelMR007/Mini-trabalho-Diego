#include <stdio.h>
#include <stdlib.h>
#include <time.h>

int main() {
    FILE *arquivo;
    int i, t, p, numero, tamanho;
    int tamanhos[4] = {100, 1000, 10000, 20000};
    char nomeArquivo[50];

    srand(time(NULL));

    for (t = 0; t < 4; t++) {
        tamanho = tamanhos[t];

        for (p = 0; p < 3; p++) {
            if (p == 0) {
                sprintf(nomeArquivo, "dados-%d-crescente.txt", tamanho);
                arquivo = fopen(nomeArquivo, "w");
                if (arquivo == NULL) {
                    return 1;
                }
                for (i = 0; i < tamanho; i++) {
                    numero = i + 1;
                    fprintf(arquivo, "%d\n", numero);
                }
                fclose(arquivo);
            } else if (p == 1) {
                sprintf(nomeArquivo, "dados-%d-decrescente.txt", tamanho);
                arquivo = fopen(nomeArquivo, "w");
                if (arquivo == NULL) {
                    return 1;
                }
                for (i = 0; i < tamanho; i++) {
                    numero = tamanho - i;
                    fprintf(arquivo, "%d\n", numero);
                }
                fclose(arquivo);
            } else {
                sprintf(nomeArquivo, "dados-%d-aleatoria.txt", tamanho);
                arquivo = fopen(nomeArquivo, "w");
                if (arquivo == NULL) {
                    return 1;
                }
                for (i = 0; i < tamanho; i++) {
                    numero = rand() % 100000;
                    fprintf(arquivo, "%d\n", numero);
                }
                fclose(arquivo);
            }
        }
    }

    printf("todos os arquivos foram gerados com sucesso\n");

    return 0;
}
